     <div class="error_section">
                            <div class="row">
                                <div class="col-12">
                                    <div class="error_form">
                                        <h1>404</h1>
                                        <h2>Không tìm thấy trang web</h2>
                                        <p>Xin lỗi nhưng trang bạn đang tìm không tồn tại, đã bị xóa, đổi tên hoặc tạm thời không có.</p>
                                        
                                       
                                    </div>
                                </div>
                            </div>
                        </div>