<?php 
define('BASE_URL', 'http://localhost:81/DuAn/web_mvc_pdo/');

 ?>