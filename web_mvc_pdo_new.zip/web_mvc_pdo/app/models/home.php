<?php 
/**
 * 
 */
class home extends DModel
{
	
	function __construct()
	{
		parent::__construct();
		
	}
	
}
?>